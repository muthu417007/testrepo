import previous from '@salesforce/label/c.BWC_Search_Results_previous';
import next from '@salesforce/label/c.BWC_Search_Results_next';
import resultsLimitHitText from '@salesforce/label/c.BWC_Search_Results_resultsLimitHitText';
export { previous, next, resultsLimitHitText };